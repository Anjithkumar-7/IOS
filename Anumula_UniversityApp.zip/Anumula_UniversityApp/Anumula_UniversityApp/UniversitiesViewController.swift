//
//  ViewController.swift
//  Anumula_UniversityApp
//
//  Created by Anumula,Anjith Kumar on 4/18/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var course_Array = courses
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return course_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = course_Array[indexPath.row].domain
        return cell
    }
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "listsSegue"{
              let destination = segue.destination as!  UniversityListViewController
              
              //Assigning product to the destination
              destination.universityList = course_Array[(universitiesTableView.indexPathForSelectedRow?.row)!].list_Array
              destination.name = course_Array[(universitiesTableView.indexPathForSelectedRow?.row)!].domain
          }
      }

        

    
    
    
}

