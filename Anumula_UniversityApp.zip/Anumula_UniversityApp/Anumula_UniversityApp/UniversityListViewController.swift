//
//  UniversityListViewController.swift
//  Anumula_UniversityApp
//
//  Created by Anumula,Anjith Kumar on 4/18/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    var universityList:[UniversityList]=[]
    var name = ""
    
    @IBOutlet weak var universityListTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = name
        
        universityListTableView.delegate = self
        universityListTableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universityList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier:"listCell", for: indexPath)
        cell.textLabel?.text = universityList[indexPath.row].collegeName
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "universityInfoSegue"{
              let destination = segue.destination as!  UniversityInfoViewController
              
              //Assigning product to the destination
              destination.imageName = universityList[(universityListTableView.indexPathForSelectedRow?.row)!].collegeImage
              destination.uniInfo = universityList[(universityListTableView.indexPathForSelectedRow?.row)!].collegeInfo
          }
      }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
