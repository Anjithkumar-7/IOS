//
//  Universities.swift
//  Anumula_UniversityApp
//
//  Created by Anumula,Anjith Kumar on 4/19/23.
//

import Foundation

struct Universities{
    var domain = ""
    var list_Array:[UniversityList] = []
}

struct UniversityList{
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
}

var nwMissouri = "NorthWest Missouri State University"
var nwMissouriInfo = "Northwest Missouri State University (NW Missouri) is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students.[4] Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum.[5] The school is governed by a state-appointed Board of Regents and headed by Interim President Clarence Green."
var purdue = "Purdue University"
var purdueInfo = "Purdue University (or simply Purdue) is a public land-grant research university in West Lafayette, Indiana, and the flagship campus of the Purdue University system.[7] The university was founded in 1869 after Lafayette businessman John Purdue donated land and money to establish a college of science, technology, and agriculture in his name."
var minnesota = "University of Minnesota"
var minnesotaInfo = "The University of Minnesota, formally the University of Minnesota, Twin Cities, (UMN Twin Cities, the U of M, or Minnesota) is a public land-grant research university in the Twin Cities of Minneapolis and Saint Paul, Minnesota, United States. The Twin Cities campus comprises locations in Minneapolis and Falcon Heights, a suburb of St. Paul, approximately 3 miles (4.8 km) apart."
var michigan = "University of Michigan"
var michiganInfo = "The University of Michigan (U-M, UMich, or Michigan) is a public research university in Ann Arbor, Michigan. Founded in 1817 as the Catholepistemiad, or the School of Universal Knowledge,the university is the oldest in Michigan it was established 20 years before the territory became a state. The University of Michigan is ranked among the top universities in the world."
var austin = "University of Texas Austin"
var austinInfo = "The University of Texas at Austin (UT Austin, UT, or Texas) is a public research university in Austin, Texas, and the flagship institution of the University of Texas System. With 40,916 undergraduate students, 11,075 graduate students and 3,133 teaching faculty as of Fall 2021, it is also the largest institution in the system."
var carolina = "North Carolina State University"
var carolinaInfo = "North Carolina State University (NC State, North Carolina State, NC State University, or NCSU)[7] is a public land-grant research university in Raleigh, North Carolina.[8] Founded in 1887 and part of the University of North Carolina system, it is the largest university in the Carolinas. "
var harvard = "Harvard University"
var harvardInfo = "Harvard University is a private Ivy League research university in Cambridge, Massachusetts. Founded in 1636 as Harvard College and named for its first benefactor, the Puritan clergyman John Harvard, it is the oldest institution of higher learning in the United States. Its influence, wealth and rankings have made it one of the most prestigious universities in the world"
var stanford = "Stanford University"
var stanfordInfo = "Stanford University, officially Leland Stanford Junior University,[13][14] is a private research university in Stanford, California. The campus occupies 8,180 acres (3,310 hectares), among the largest in the United States, and enrolls over 17,000 students.[15] Stanford is widely considered to be one of the most prestigious universities in the world"
var california = "University of California"
var californiaInfo = "The University of California (UC) is a public land-grant research university system in the U.S. state of California. The system is composed of its ten campuses at Berkeley, Davis, Irvine, Los Angeles, Merced, Riverside, San Diego, San Francisco, Santa Barbara, and Santa Cruz, along with numerous research centers and academic abroad centers.[5] The system is the state's land-grant university."
var columbia = "Columbia University"
var columbiaInfo = "Columbia University (colloquially known as Columbia; officially as Columbia University in the City of New York) is a private Ivy League research university in New York City. Established in 1754 as King's College on the grounds of Trinity Church in Manhattan, it is the oldest institution of higher education in New York, the fifth-oldest in the United States"
var duke = "Duke University"
var dukeInfo = "Duke University is a private research university in Durham, North Carolina. Founded by Methodists and Quakers in the present-day city of Trinity in 1838, the school moved to Durham in 1892.[13] In 1924, tobacco and electric power industrialist James Buchanan Duke established The Duke Endowment and the institution changed its name to honor his deceased father, Washington Duke."
 


let course1 = Universities(domain: "Information Technology",list_Array: [UniversityList(collegeName: nwMissouri,collegeImage: nwMissouri,collegeInfo: nwMissouriInfo),UniversityList(collegeName: purdue,collegeImage: purdue,collegeInfo: purdueInfo),UniversityList(collegeName: minnesota,collegeImage: minnesota,collegeInfo: minnesotaInfo),UniversityList(collegeName: michigan,collegeImage: michigan,collegeInfo: michiganInfo),UniversityList(collegeName: austin,collegeImage: austin,collegeInfo: austinInfo),UniversityList(collegeName: carolina,collegeImage: carolina,collegeInfo: carolinaInfo)])

let course2 = Universities(domain: "Computer Science",list_Array: [UniversityList(collegeName: harvard,collegeImage: harvard,collegeInfo: harvardInfo),UniversityList(collegeName: stanford,collegeImage: stanford,collegeInfo: stanfordInfo),UniversityList(collegeName: columbia,collegeImage: columbia,collegeInfo: columbiaInfo),UniversityList(collegeName: duke,collegeImage: duke,collegeInfo: dukeInfo),UniversityList(collegeName: austin,collegeImage: austin,collegeInfo: austinInfo),UniversityList(collegeName: carolina,collegeImage: carolina,collegeInfo: carolinaInfo)])

let course3 = Universities(domain: "Data Science And Analytics",list_Array: [UniversityList(collegeName: harvard,collegeImage: harvard,collegeInfo: harvardInfo),UniversityList(collegeName: stanford,collegeImage: stanford,collegeInfo: stanfordInfo),UniversityList(collegeName: columbia,collegeImage: columbia,collegeInfo: columbiaInfo),UniversityList(collegeName: nwMissouri,collegeImage: nwMissouri,collegeInfo: nwMissouriInfo),UniversityList(collegeName: purdue,collegeImage: purdue,collegeInfo: purdueInfo),UniversityList(collegeName: minnesota,collegeImage: minnesota,collegeInfo: minnesotaInfo)])

let course4 = Universities(domain: "Cyber Security",list_Array: [UniversityList(collegeName: nwMissouri,collegeImage: nwMissouri,collegeInfo: nwMissouriInfo),UniversityList(collegeName: purdue,collegeImage: purdue,collegeInfo: purdueInfo),UniversityList(collegeName: minnesota,collegeImage: minnesota,collegeInfo: minnesotaInfo),UniversityList(collegeName: purdue,collegeImage: purdue,collegeInfo: purdueInfo),UniversityList(collegeName: minnesota,collegeImage: minnesota,collegeInfo: minnesotaInfo)])
                               
                               
let courses = [course1,course2,course3,course4]
