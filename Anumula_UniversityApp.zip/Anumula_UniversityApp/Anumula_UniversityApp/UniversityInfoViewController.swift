//
//  UniversityInfoViewController.swift
//  Anumula_UniversityApp
//
//  Created by Anumula,Anjith Kumar on 4/18/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    var imageName = ""
    var uniInfo = ""
    
    @IBOutlet weak var uniImageView: UIImageView!
    
    
    @IBOutlet weak var uniInfoOL: UITextView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = imageName
        uniInfoOL.isHidden = true
        let imageView = UIImageView(image: UIImage(named: imageName))
        imageView.frame = CGRect(x: 195, y: 183, width: 240, height: 150)
        view.addSubview(imageView)
        // Animate the image view's position from left to right
        UIView.animate(withDuration: 0.5, animations: {
            imageView.frame.origin.x -= 120
        })

        
    }
    
    @IBAction func uniInfoBtn(_ sender: Any) {
        uniInfoOL.isHidden = false
        uniInfoOL.text = uniInfo
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

        
}
