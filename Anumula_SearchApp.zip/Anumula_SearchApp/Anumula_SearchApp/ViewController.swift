//
//  ViewController.swift
//  Anumula_SearchApp
//
//  Created by Anumula,Anjith Kumar on 3/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    var prev = 0
    var nxt = 0
    var topic = -1
    var topicImages:[String] = []
    var topicDesc:[String] = []
    
    let topic_arr = [["Img01","Img02","Img03","Img04","Img05"],["Img11","Img12","Img13","Img14","Img15"],
                     ["Img21","Img22","Img23","Img24","Img25"]]
    let topic_desc = [["Konidela Ram Charan Teja (born 27 March 1985) is an Indian actor, producer, and entrepreneur who primarily works in Telugu films. One of the highest-paid actors in Indian cinema,[3][4] he is the recipient of three Filmfare Awards and two Nandi Awards. Since 2013, he has featured in Forbes India's Celebrity 100 list","Nandamuri Taraka Rama Rao Jr. (born 20 May 1983), also known as Jr NTR or Tarak, is an Indian actor who primarily works in Telugu cinema. One of the highest paid Telugu film actors,[1][2] Rama Rao Jr. has won several accolades, including two Filmfare Awards, two state Nandi Awards, and four CineMAA Awards. Since 2012, he has been featured in Forbes India Celebrity 100 list.","Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas ([pɾabʱaːs]), is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema,[4] Prabhas has featured in Forbes India's Celebrity 100 list three times since 2015 based on his income and popularity.","Akkineni Naga Chaitanya (born 23 November 1986) is an Indian actor who primarily works in Telugu cinema. He made his acting debut with Josh (2009) and his breakthrough came with Gautham Vasudev Menon-directed Ye Maaya Chesave (2010).","Allu Arjun (born 8 April 1982) is an Indian actor who works in Telugu films. One of the highest paid actors in India,[3] Arjun is also known for his extraordinary dancing skills.[4] He is a recipient of several awards including six Filmfare Awards and three Nandi Awards."],["Rohit Gurunath Sharma (born 30 April 1987), is an Indian international cricketer and the current captain of India men’s cricket team in all formats. Considered as one of the best batsman of his generation and one of greatest opening batters of all time,[1] Rohit is known for his timing, elegance, six-hiting abilities and leadership skills.","Virat Kohli (Hindi pronunciation: [ʋɪˈɾɑːʈ ˈkoːɦli] (listen); born 5 November 1988) is an Indian international cricketer and the former captain of the India national team who plays as a right-handed batsman for Royal Challengers Bangalore in the IPL and for the Delhi in Indian domestic cricket.","Ravindrasinh Anirudhsinh Jadeja (born 6 December 1988), commonly known as Ravindra Jadeja, is an Indian international cricketer. He is an all-rounder, who bats left-handed and bowls left-arm orthodox spin. He was the captain of the Chennai Super Kings in the Indian Premier League. He represents Saurashtra in first-class cricket.","Mahendra Singh Dhoni (/məˈheɪndrə ˈsɪŋ dhæˈnɪ/ (listen); born 7 July 1981), commonly known as MS Dhoni, is a former Indian cricketer and captain of the Indian national team in limited-overs formats from 2007 to 2017, and in Test cricket from 2008 to 2014. He is also the current captain of Chennai Super Kings in the Indian Premier League. ","Sachin Ramesh Tendulkar BR (/ˌsʌtʃɪn tɛnˈduːlkər/ (listen); pronounced [sət͡ʃin t̪eːɳɖulkəɾ]; born 24 April 1973) is an Indian former international cricketer who captained the Indian national team. Nicknamed "The Little Master"[4] and "Master Blaster"[5], he is regarded as one of the greatest batsmen in the history of cricket."],["Iron Man","Capatain America","Batman","Flash","Thor"]]
    
    let actors_keywords = ["film","actor","movie","star","hero"]
    let cricket_keywords = ["bat","cricket","cricketers","ball","wicket","player"]
    let character_keywords = ["marvel","DC","batman","super","comic","characters"]
    
    @IBOutlet weak var nxtBtnOtl: UIButton!
    
    @IBAction func searchButtonAction(_ sender: Any) {
        prev = 0
        nxt = 0
        if(actors_keywords.contains(searchTextField.text!)){
            topic = 0
            }
        else if(cricket_keywords.contains(searchTextField.text!)){
            topic = 1
        }else if(character_keywords.contains(searchTextField.text!)){
            topic = 2
        }
        switch(topic){
        case 0,1,2:
            prevBtnOtl.isHidden = false
            rstBtnOtl.isHidden = false
            nxtBtnOtl.isHidden = false
            topicImages = topic_arr[topic]
            topicDesc = topic_desc[topic]
            imageView.image = UIImage(named: topicImages[0])
            topicInfoText.text = topicDesc[0]
            prevBtnOtl.isEnabled = false
            nxtBtnOtl.isEnabled = true
        default:
            imageView.image = UIImage(named: "Ooops2")
            topicInfoText.text = ""
            hideelements()
        }
        
        }
    
    func showRelatedContext( i :Int){
        imageView.image = UIImage(named: topicImages[i])
        topicInfoText.text = topicDesc[i]
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        nxt = nxt+1
        showRelatedContext(i:nxt)
        if(nxt == topic_arr[topic].count-1){
            nxtBtnOtl.isEnabled = false
            prev = prev+1
            nxt = 0
        }else{
            prev = prev+1
            prevBtnOtl.isEnabled = true
        }
         
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        prev = prev-1
        showRelatedContext(i: prev)
        if(prev == 0){
            prevBtnOtl.isEnabled = false
           nxt = 0
        }else{
            nxt = nxt+1
            nxtBtnOtl.isEnabled = true
        }
        
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        prev = 0
        nxt = 0
        topicImages = []
        topicDesc = []
        topic = -1
        imageView.image = UIImage(named: "Welcome")
        topicInfoText.text = ""
        hideelements()
    }
    
    @IBOutlet weak var rstBtnOtl: UIButton!
    
    @IBOutlet weak var prevBtnOtl: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: "Welcome")
        hideelements()
    }
 
    func hideelements(){
        prevBtnOtl.isHidden = true
        rstBtnOtl.isHidden = true
        nxtBtnOtl.isHidden = true
    }

}


