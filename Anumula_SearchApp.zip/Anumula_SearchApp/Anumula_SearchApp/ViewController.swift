//
//  ViewController.swift
//  Anumula_SearchApp
//
//  Created by Anumula,Anjith Kumar on 3/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    var prev = 0
    var nxt = 0
    var topic = -1
    var topicImages:[String] = []
    var topicDesc:[String] = []
    
    let topic_arr = [["Img01","Img02","Img03","Img04","Img05"],["Img11","Img12","Img13","Img14","Img15"],
                     ["Img21","Img22","Img23","Img24","Img25"]]
    let topic_desc = [["Ramcharan","NTR","Prabhas","NagaChaitanya","AlluArjun"],["RohitSharma","ViratKohli","Jadeja","M S Dhoni","Sachin Tendulkar"],["Iron Man","Capatain America","Batman","Flash","Thor"]]
    
    let actors_keywords = ["film","actor","movie","star","hero"]
    let cricket_keywords = ["bat","cricket","cricketers","ball","wicket","player"]
    let character_keywords = ["marvel","DC","batman","super","comic","characters"]
    
    @IBOutlet weak var nxtBtnOtl: UIButton!
    
    @IBAction func searchButtonAction(_ sender: Any) {
        prev = 0
        nxt = 0
        if(actors_keywords.contains(searchTextField.text!)){
            topic = 0
            }
        else if(cricket_keywords.contains(searchTextField.text!)){
            topic = 1
        }else if(character_keywords.contains(searchTextField.text!)){
            topic = 2
        }
        switch(topic){
        case 0,1,2:
            prevBtnOtl.isHidden = false
            rstBtnOtl.isHidden = false
            nxtBtnOtl.isHidden = false
            topicImages = topic_arr[topic]
            topicDesc = topic_desc[topic]
            imageView.image = UIImage(named: topicImages[0])
            topicInfoText.text = topicDesc[0]
            prevBtnOtl.isEnabled = false
            nxtBtnOtl.isEnabled = true
        default:
            imageView.image = UIImage(named: "Ooops2")
            topicInfoText.text = ""
            hideelements()
        }
        
        }
    
    func showRelatedContext( i :Int){
        imageView.image = UIImage(named: topicImages[i])
        topicInfoText.text = topicDesc[i]
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        nxt = nxt+1
        showRelatedContext(i:nxt)
        if(nxt == topic_arr[topic].count-1){
            nxtBtnOtl.isEnabled = false
            prev = prev+1
            nxt = 0
        }else{
            prev = prev+1
            prevBtnOtl.isEnabled = true
        }
         
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        prev = prev-1
        showRelatedContext(i: prev)
        if(prev == 0){
            prevBtnOtl.isEnabled = false
           nxt = 0
        }else{
            nxt = nxt+1
            nxtBtnOtl.isEnabled = true
        }
        
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        prev = 0
        nxt = 0
        topicImages = []
        topicDesc = []
        topic = -1
        imageView.image = UIImage(named: "Welcome")
        topicInfoText.text = ""
        hideelements()
    }
    
    @IBOutlet weak var rstBtnOtl: UIButton!
    
    @IBOutlet weak var prevBtnOtl: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: "Welcome")
        hideelements()
    }
 
    func hideelements(){
        prevBtnOtl.isHidden = true
        rstBtnOtl.isHidden = true
        nxtBtnOtl.isHidden = true
    }

}


