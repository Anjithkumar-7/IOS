//
//  ViewController.swift
//  ChowMein
//
//  Created by Anumula,Anjith Kumar on 4/19/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

