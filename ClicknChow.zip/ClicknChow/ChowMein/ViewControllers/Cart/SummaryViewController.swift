//
//  SummaryViewController.swift
//  ClickNChow
//
//  Created by Palavelli,Anil Kumar on 4/30/23.
//

import UIKit

class SummaryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var orderTV: UITableView!
    @IBOutlet weak var totalPriceLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if Order.orderItems.count == 0 {
            totalPriceLBL.text = "0.0"
        } else {
            var totalPrice = 0.0
            
            for orderItem in Order.orderItems {
                totalPrice = totalPrice + (orderItem.itemPrice * Double(orderItem.itemQuantity))
            }
            
            totalPriceLBL.text = "\(totalPrice)"
        }
        
        orderTV.dataSource = self
        orderTV.delegate = self
        self.orderTV.register(UINib(nibName: "OrderSummaryTVC", bundle: nil), forCellReuseIdentifier: "orderCell")
    }
    
    @IBAction func confirmOrder(_ sender: UIBarButtonItem) {
        if Order.orderItems.count == 0 {
            let alert = UIAlertController(title: "Empty Cart", message: "Please slect atleast one item", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default))
            self.present(alert, animated: true)
        } else {
            performSegue(withIdentifier: "confrimOrderSegue", sender: self)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        Order.orderItems.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if Order.tableNumber != -1 {
            return "Table No. \(Order.tableNumber)"
        }
        return "TakeOut"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "orderCell", for: indexPath) as? OrderSummaryTVC else {return UITableViewCell()}
        
        cell.itemDetails.text = "\(Order.orderItems[indexPath.row].itemName) - \(Order.orderItems[indexPath.row].itemQuantity)"
        let totalPrice = Order.orderItems[indexPath.row].itemPrice * Double(Order.orderItems[indexPath.row].itemQuantity)
        cell.itemPrice.text = "\(totalPrice)"
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var trans=segue.identifier
        if trans == "confrimOrderSegue" {
            var des = segue.destination as! PaymentViewController
            des.totalPrice=totalPriceLBL.text!
            
        }
    }

}
