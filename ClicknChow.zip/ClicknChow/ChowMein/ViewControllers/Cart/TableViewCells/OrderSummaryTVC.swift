//
//  OrderSummaryTVC.swift
//  ClickNChow
//
//  Created by Palavelli,Anil Kumar on 4/30/23.
//

import UIKit

class OrderSummaryTVC: UITableViewCell {

    @IBOutlet weak var itemDetails: UILabel!
    @IBOutlet weak var itemPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
