//
//  HomeVC.swift
//  ClickNChow
//
// Created by Anumula,Anjith Kumar on 4/24/23.
//

import UIKit

class HomeVC: UIViewController {

   
    @IBOutlet weak var logoView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        if identifier == "takeOutSegue" {
            guard let destination = segue.destination as? MenuTypeVC else {return}
            Order.tableNumber = -1
            destination.tableNumber = "TakeOut"
        }
    }
}
