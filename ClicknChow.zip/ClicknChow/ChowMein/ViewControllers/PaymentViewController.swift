//
//  PaymentViewController.swift
//  ClickNChow
//
//  Created by Chitrala,Bhanuteja on 4/30/23.
//

import UIKit

class PaymentViewController: UIViewController, UITableViewDelegate,
                             UITableViewDataSource {
    
    
    @IBOutlet weak var payOL: UIButton!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        PaymentMethod.paymentOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = paymentOptTV.dequeueReusableCell(withIdentifier: "paymentCell", for: indexPath)
        
        //popolate a cell with data
        myCell.textLabel?.text = PaymentMethod.paymentOptions[indexPath.row]
        //return a cell
        return myCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        payOL.isEnabled = true
        let alert = UIAlertController(title: "Payment Option : \(PaymentMethod.paymentOptions[indexPath.row])", message: "Please enter details", preferredStyle: .alert
        )
        
        if(PaymentMethod.paymentOptions[indexPath.row] != "Cash" && PaymentMethod.paymentOptions[indexPath.row] != "Apple Pay"){
            alert.addTextField{ textField in
                textField.placeholder = "Card Number"
                textField.keyboardType = .numberPad
            }
            alert.addTextField{ textField in
                textField.placeholder = "Expiry Date"
                textField.keyboardType = .numberPad
            }
            alert.addTextField { textField in
                textField.placeholder = "CVV"
                textField.keyboardType = .numberPad
                textField.isSecureTextEntry = true
            }
            alert.addAction(UIAlertAction(title: "ok", style: .default))
            present(alert, animated: true)
        }
    }

    var totalPrice=""
    
    @IBOutlet weak var paymentOptTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        payOL.isEnabled = false
        paymentOptTV.delegate=self
        paymentOptTV.dataSource=self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
