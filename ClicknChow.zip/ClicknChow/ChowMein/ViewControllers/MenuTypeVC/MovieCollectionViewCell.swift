//
//  MovieCollectionViewCell.swift
//  ClickNChow
//
//  Created by Anumula,Anjith Kumar on 4/24/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var foodItemImage:UIImageView!
    
    func assignFoodImage(with foodImage:String){
        foodItemImage.image = UIImage(named: foodImage)
    }
    
    
}
