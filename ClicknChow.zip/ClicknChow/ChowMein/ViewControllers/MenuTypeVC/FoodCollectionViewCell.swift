//
//  FoodCollectionViewCell.swift
//  ClickNChow
//
//  Created by Anumula,Anjith Kumar on 4/24/23.
//

import Foundation

class FoodCollectionViewCell
