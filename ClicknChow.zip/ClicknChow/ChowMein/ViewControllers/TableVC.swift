//
//  HomeVC.swift
//  ClickNChow
//
//  Created by Chitrala,Bhanuteja on 4/23/23.
//

import UIKit

class TableVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func tableSelected(_ sender: UIButton) {
        performSegue(withIdentifier: "menuSegue", sender: sender.titleLabel?.text)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        if identifier == "menuSegue" {
            guard let destination = segue.destination as? MenuTypeVC, let tableNumber = sender as? String else {return}
            destination.tableNumber = tableNumber
            Order.tableNumber = Int(tableNumber) ?? 0
        }
    }
}
