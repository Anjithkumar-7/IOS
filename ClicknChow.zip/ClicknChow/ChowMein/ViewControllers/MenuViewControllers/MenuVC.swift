//
//  MenuVC.swift
//  ChowMein
//
//  Created by Chitrala,Bhanuteja on 4/23/23.
//

import UIKit

class MenuVC: UIViewController {

    @IBOutlet weak var menuTable: UITableView!
    
    
    @IBOutlet weak var checkoutBtnOL: UIBarButtonItem!
    
    var menuType: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.menuTable.delegate = self
        self.menuTable.dataSource = self
        self.menuTable.register(UINib(nibName: "MenuTVC", bundle: nil), forCellReuseIdentifier: "menuItem")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MenuVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if menuType == "Vegeterian" {
            return AppConstants.vegMenuItems.count
        }
        return AppConstants.nonVegMenuItems.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if Order.tableNumber != -1 {
            return "Table No. \(Order.tableNumber)"
        }
        return "TakeOut"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "menuItem", for: indexPath) as? MenuTVC else {return UITableViewCell()}
        if menuType == "Vegeterian" {
            cell.menuItemLBL.text = "\(AppConstants.vegMenuItems[indexPath.row].itemName) - \(AppConstants.vegMenuItems[indexPath.row].itemPrice)"
            cell.quantityLBL.text = "\(AppConstants.vegMenuItems[indexPath.row].itemQuantity)"
        } else {
            cell.menuItemLBL.text = "\(AppConstants.nonVegMenuItems[indexPath.row].itemName) - \(AppConstants.nonVegMenuItems[indexPath.row].itemPrice)"
            cell.quantityLBL.text = "\(AppConstants.nonVegMenuItems[indexPath.row].itemQuantity)"
        }
        return cell
    }
}
