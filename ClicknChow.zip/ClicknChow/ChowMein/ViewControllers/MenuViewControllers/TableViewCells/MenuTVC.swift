//
//  MenuTVC.swift
//  ChowMein
//
//  Created by Chitrala,Bhanuteja on 4/23/23.
//

import UIKit

class MenuTVC: UITableViewCell {

    @IBOutlet weak var menuItemLBL: UILabel!
    @IBOutlet weak var quantityLBL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func minItem(_ sender: UIButton) {
        guard let quantity = quantityLBL.text, let quantityInt = Int(quantity) else {return}
        guard let selectedItem = menuItemLBL.text else {return}
        
        if quantityInt == 0 {
            
        } else if quantityInt == 1 {
            quantityLBL.text = "\(quantityInt - 1)"
            
            for (i, menuItem) in Order.orderItems.enumerated() {
                if "\(menuItem.itemName) - \(menuItem.itemPrice)" == selectedItem {
                    Order.orderItems.remove(at: i)
                }
            }
        } else {
            quantityLBL.text = "\(quantityInt - 1)"
            
            for (i, menuItem) in Order.orderItems.enumerated() {
                if "\(menuItem.itemName) - \(menuItem.itemPrice)" == selectedItem {
                    Order.orderItems[i].itemQuantity = quantityInt - 1
                }
            }
        }
    }

    @IBAction func maxItem(_ sender: UIButton) {
        guard let quantity = quantityLBL.text, let quantityInt = Int(quantity) else {return}
        guard let selectedItem = menuItemLBL.text else {return}
        
        quantityLBL.text = "\(quantityInt + 1)"
        
        var hasItem: Bool = false
        
        for (i, menuItem) in Order.orderItems.enumerated() {
            if "\(menuItem.itemName) - \(menuItem.itemPrice)" == selectedItem {
                hasItem = true
                Order.orderItems[i].itemQuantity = quantityInt + 1
            }
        }
        
        if hasItem == false {
            for menuItem in AppConstants.vegMenuItems {
                if "\(menuItem.itemName) - \(menuItem.itemPrice)" == selectedItem {
                    let menuItemNew = Menu(itemName: menuItem.itemName, itemPrice: menuItem.itemPrice, itemQuantity: 1)
                    Order.orderItems.append(menuItemNew)
                }
            }
            
            for menuItem in AppConstants.nonVegMenuItems {
                if "\(menuItem.itemName) - \(menuItem.itemPrice)" == selectedItem {
                    let menuItemNew = Menu(itemName: menuItem.itemName, itemPrice: menuItem.itemPrice, itemQuantity: 1)
                    Order.orderItems.append(menuItemNew)
                }
            }
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
