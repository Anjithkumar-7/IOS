//
//  ResultViewController.swift
//  TemperatureConverter
//
//  Created by Anumula,Anjith Kumar on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    
    @IBOutlet weak var tempinCelsius: UILabel!
    
    
    @IBOutlet weak var tempinFarenheit: UILabel!
    
    var tempCelsius = ""
    var tempFarenheit = ""
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(tempCelsius != ""){
            tempinCelsius.text = tempinCelsius.text!+" "+tempCelsius+"°C"
            tempinFarenheit.text = tempinFarenheit.text!+" "+tempFarenheit+"F"
        }else if(tempFarenheit != ""){
            tempinFarenheit.text = tempinFarenheit.text!+" "+tempFarenheit+"F"
            tempinCelsius.text = tempinCelsius.text!+" "+tempCelsius+"°C"
        }
        // Do any additional setup after loading the view.
    }

}
