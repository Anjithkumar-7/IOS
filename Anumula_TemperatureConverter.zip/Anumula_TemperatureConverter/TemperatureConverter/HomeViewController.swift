//
//  ViewController.swift
//  TemperatureConverter
//
//  Created by Anumula,Anjith Kumar on 4/3/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    
    @IBOutlet weak var tempInCelsius: UITextField!
    
    
    @IBOutlet weak var tempInFarenheit: UITextField!
    
    var covertedTemp:Double = 0.0
    
    @IBAction func farenheitEntered(_ sender: Any) {
        if(tempInCelsius.text! != ""){
            tempInFarenheit.isEnabled = false
            tempInFarenheit.isHidden = true
        }else{
            tempInFarenheit.isHidden = false
            tempInFarenheit.isEnabled = true
        }
    }
    
    
    @IBAction func celsiusEntered(_ sender: UITextField) {
        if(tempInFarenheit.text! != ""){
            tempInCelsius.isHidden = true
            tempInCelsius.isEnabled = false
        }else{
            tempInCelsius.isHidden = false
            tempInCelsius.isEnabled = true
        }
    }
    
    
    @IBAction func convertTemp(_ sender: Any) {
        var celsiusTemp = Double(tempInCelsius.text!)
        var farenheitTemp = Double(tempInFarenheit.text!)
        if(celsiusTemp != nil){
            covertedTemp = ((celsiusTemp!/5)*9)+32
        }else if(farenheitTemp != nil){
            covertedTemp = ((farenheitTemp!-32)/9)*5
        }
    }
    
  override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
        }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "ResultSegue"{
            var destinition = segue.destination as! ResultViewController
            if(tempInCelsius.text == ""){
                destinition.tempCelsius = String(covertedTemp)
                destinition.tempFarenheit = tempInFarenheit.text!
                
            }else if(tempInFarenheit.text == ""){
                destinition.tempFarenheit = String(covertedTemp)
                destinition.tempCelsius = tempInCelsius.text!
            }
            
        }
    }
}
    
