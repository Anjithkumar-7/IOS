//
//  Student.swift
//  StudentApp
//
//  Created by Anumula,Anjith Kumar on 4/4/23.
//

import Foundation


struct Student{
    
    var name = ""
    var sid = ""
    var email = ""
    var phoneNo = ""
    
    var Courses:[Course] = []
    
}

struct Course{
    
    var crn = ""
    var title = ""
    var sem = ""
    
}


let s1 = Student(name: "Anjith", sid: "S554041", email: "S554041@nwmissouri.edu", phoneNo: "8976543022", Courses: [Course(crn: "43524", title: "IOS", sem: "sp23"),Course(crn: "65748", title: "JAVA", sem: "fall22"),Course(crn: "45632", title: "Patterns", sem: "sp23")])

let s2 = Student(name: "Bhanu", sid: "S554982", email: "S994982@nwmissouri.edu", phoneNo: "6605467893", Courses: [Course(crn: "45673", title: "ProjectManagement", sem: "sp23"),Course(crn: "567432", title: "IOS", sem: "sp23"),Course(crn: "564732", title: "ADB", sem: "fall22")])

let s3 = Student(name: "Anil", sid: "S554678", email: "S554678@nwmissouri.edu", phoneNo: "6787654234", Courses: [Course(crn: "234563", title: "IOS", sem: "sp23"),Course(crn: "345267", title: "WebApps", sem: "fall22"),Course(crn: "675453", title: "Java", sem: "sp23")])

let Students:[Student] = [s1,s2,s3]
