//
//  ViewController.swift
//  StudentApp
//
//  Created by Anumula,Anjith Kumar on 4/4/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var sIdOutlet: UITextField!
    
    var sArray = Students
    var sFound = Student()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

  
    @IBAction func studentDetailsBtn(_ sender: Any) {
        for student in sArray{
            if(student.sid == sIdOutlet.text!){
                sFound = student
            }
        }
                    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
    
        
        
        
    }
    
}

